/** Automatically generated file. DO NOT MODIFY */
package tvb.box.tvbboxclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}